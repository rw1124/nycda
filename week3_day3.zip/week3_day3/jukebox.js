function Jukebox () {
	this.songs = [];
	this.currentSong = "";
	this.increaseVolume = function () {
		if (this.currentSong!="") {
		document.getElementById(this.currentSong.id).volume+=0.1;
		}
	}
	this.decreaseVolume = function () {
		if (this.currentSong!="") {
			document.getElementById(this.currentSong.id).volume-=0.1;
		}
	}
	this.play = function (song) {
		console.log(song);
		this.pause();
		this.currentSong = song;
		songToPlay = song;
		console.log("SongToPlay");
		console.log(songToPlay);
		document.getElementById(song.id).play();
		console.log("Starting: "+this.currentSong.songName+" at "+document.getElementById(this.currentSong.id).currentTime);
		document.getElementById("current-song").innerHTML = song.songName;

	}
	this.pause = function () {
		console.log('Made it to pause song');
		if (this.currentSong!=""){
			if (!document.getElementById(this.currentSong.id).paused){
				document.getElementById(this.currentSong.id).pause();
			}
			// setTimer to allow pause to complete action -- can throw DOM promise exception occassionally
			setTimeout(function(){},150);
			console.log("Pausing: "+this.currentSong.songName+" at "+document.getElementById(this.currentSong.id).currentTime);
		} else {
			console.log("Nothing to pause");
		}
	}
	this.stop = function () {
		console.log('Made it to stop song');
		this.pause();
		// reset start point to zero
		var currentSongElement = document.getElementById(this.currentSong.id)
		currentSongElement.currentTime = 0;
		console.log("Stop currentTime = "+ currentSongElement.currentTime);
	}
	this.shuffle = function () {
		// randomSongIndex =generate a random number from 0 to maximum songs array length
		var randomNumberIndex = Math.floor(Math.random() * (this.songs.length));
		console.log("random index is: "+randomNumberIndex);
		var randomSong = this.songs[randomNumberIndex];
		// reset current song to start a begining if one was playing
		if (this.currentSong!=""){
			this.stop();
			console.log(this.currentSong.songName+" is reset to " + document.getElementById(this.currentSong.id).currentTime);
		}
		this.play(randomSong);
	}
	this.addSong = function (song){
	this.songs.push(song);
	}
}

function Song (songName, artist, id) {
	this.songName = songName;
	this.artist = artist;
	this.id = id;
	this.queue = false;
	this.getElement = function(){
		return document.getElementById(this.id)
	}
}

function playSongWithReset(song){
	if (bob.currentSong!=""){
		bob.stop();
	}
	bob.play(song);
}

function playSong(song){
	bob.play(song);
}

function stopSong(){
	bob.stop();
}

function pauseSong(){
	bob.pause();
}

function increaseVolume() {
	bob.increaseVolume();
}

function decreaseVolume() {
	bob.decreaseVolume();
}

function shuffle() {
	bob.shuffle();
}

var bob = new Jukebox();

var wishSong = new Song("Wish", "Wishbone", 'wish');
var sixteenSong = new Song("16", "Soapbox Pushers", '16');
var commonSong = new Song("Common", "George and the Hendersons",'common');
var highwaymanSong = new Song("Highwayman", "Willie on Lean",'highwayman');


bob.addSong(wishSong);
bob.addSong(sixteenSong);
bob.addSong(commonSong);
bob.addSong(highwaymanSong);

$(document).ready(function() {
songToPlay = bob.songs[0];
	// songToPlay = bob.shuffle();
});









